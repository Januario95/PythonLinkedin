class Calculator:
    pass