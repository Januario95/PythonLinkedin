def pairwise_offset(sequence, fillvalue, offset):
    pass
