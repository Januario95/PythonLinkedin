
def html2markdown(html):
    '''Take in html text as input and return markdown'''
    pass